import actions from './actions';

const initState = {
  config: {
    layouts: {
      lg: [],
      md: []
    },
    keys: []
  }
};
