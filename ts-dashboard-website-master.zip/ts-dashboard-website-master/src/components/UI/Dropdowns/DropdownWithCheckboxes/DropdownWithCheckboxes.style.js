export const styles = {
  menu: {
    background: '#fff',
  },
  menuItem: {
    width: '250px',
    color: '#000',
    minHeight: '24px',
    height: '100%',
    fontSize: 14,
  },
};
