import React from 'react';

import * as C from './style';

const Input = props => {
  return <C.StyledInput {...props} />;
};

export default Input;
