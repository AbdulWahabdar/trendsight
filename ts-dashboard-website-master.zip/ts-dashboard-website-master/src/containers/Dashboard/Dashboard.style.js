import styled from 'styled-components';
import { Responsive } from 'react-grid-layout';

export const Wrapper = styled(Responsive)``;
export const GridItem = styled.div`
  padding: 40px 15px 20px 15px;
`;
