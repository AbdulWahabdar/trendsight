import ruMessages from '../locales/ru_RU.json';

const RuLang = {
  messages: {
    ...ruMessages
  },
  locale: 'ru-RU'
};

export default RuLang;
