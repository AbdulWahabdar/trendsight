# ts-dashboard
Trends Sight analytics dashboard

## Started guide

Clone the repository with `git clone ${repository url}`

Open the terminal from the project folder and run `npm install`

Run `npm start`

The application will open on the `http://localhost:8084`
